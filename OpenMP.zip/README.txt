Sirbu Maria-Dorinela
332CB
Tema 1 - APD

Sistemul de Operare pe care a fost facuta tema: Linux, Ubuntu.
CPU: i7, 2.4GHz.

Implementare seriala:
	
	Pentru implementare seriala a temei pentru fiecare element din matrice am mai parcurs inca o data matrice pentru a calcula dimensiunile minime pana la fiecare culoare. Aceste minime le retin intr-un vector de dimensiune NC = numarul de partide politice. Dupa ce am umplut vectorul cu aceste minimuri calculez maximul din acest vector, iar matrice[i][j] = indicele maximului.
	Complexitate este: s * O(n^4) unde s este numarul de saptamani 
	De asemenea, cand trec la urmatoarea saptamana actualizez matricea de intrare si vectorii.
	
Implementare paralela:

	Pentru implementare paralela pentru varianta neoptimizata a temei am paralelizat instructiunea "for" care urmeaza dupa parcurgerea numarului de saptamani (adica primul for de la parcurgerea matricei). In continuare am pus o zona critica acolo unde numar partidele.
	Timpi rulare:
	-pentru fisierul in100_20, 4 coruri => aproximativ 2 minute si 5 secunde
	-pentru fisierul in100_20, 8 coruri => aproximativ 2 minute 
	-pentru fisierul in50_7, 4 coruri => aproximativ 5 secunde
	-pentru fisierul in50_7, 8 coruri => aproximativ 4 secunde
	
	Pentru implementarea paralela pentru varianta optimizata a temei am paralelizat la fel instructiunea "for" care urmeaza dupa parcurgerea numarului de saptamani (adica primul for de la parcurgerea matricei). In continuare am pus o zona critica acolo unde numar partidele.
	
	Tip schedule : static
	Valoare chunk = dimensiune matrice.
Optimizare:

	Pentru realizarea variantei optimizate am folosit algoritmul dat in enuntul temei. Pentru fiecare element al matricei parcurg zonele concentrice pana cand imi completez intreg vectorul cu minime.
	Timpul pentru optimizare este in jur de 48 secunde.
	
	
	In arhiva am inclus si un makefile pentru cele 4 programe.
	
