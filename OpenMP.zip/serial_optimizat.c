#include<stdio.h>
#include<stdlib.h>

//functie care returneaza elementul maxim dintr-un vector cu un numar de elemente dat ca parametru
int maxim(int v[], int num_elements){
	int max = -1, i;
	int indice = 0;
	for(i = num_elements - 1; i >= 0; i--){
		if(v[i] >= max && v[i]<1000){
			max = v[i];	
			indice = i;
		}
	}
	return indice;
}
int maxim_vector(int v[], int num_elements, int delete[]){
	int max = -1, i;
	for(i = 0; i < num_elements; i++){
		if(v[i] > max)
			if(delete[i] < 0)
				max = v[i];
	}
	return max;
}
int minim(int n1, int n2){
	int min = 0;
	if(n1 >= n2)
		return n2;
	else
		return n1;
}
int main(int argc,char *argv[]){
	int dim_matrice;//dimensiune matrice intrare
	int NC;//numarul de [artide
    int nr_saptamani;//numar saptamani
	
	FILE *fisin, *fisout;//fisierele de intrare respectiv iesire
	fisin = fopen(argv[2], "r");//deschid fisierul de intrare pentru citire(al doilea argument)
	fisout = fopen(argv[3], "w");//deschid fiaierul de iesire pentru scriere(al treilea argument)
	nr_saptamani = atoi(argv[1]);//primul argument
	int x;		
	int afara = 0, afara1 = 0,afara2 = 0,afara3 = 0;
	int i,j,k,m,n;//indici utilizati pentru parcurgeri
	fscanf(fisin,"%i",&dim_matrice);//citesc prima linie din fisier care este dimensiunea matrici
	int matrice[dim_matrice][dim_matrice];//matricea de intrare
	int matrice_iesire[dim_matrice][dim_matrice];//matricea de iesire
	fscanf(fisin,"%i",&NC);//citesc a doua linie din fisier care reprezinta numarul de partide
	int vector_culori[NC];//vector in care retin distantele minime
	int numar_culori[NC];//vector in care retin numarul partidelor dupa fiecare saptamana
	int copy[NC];//vector
	int vector1[NC];
	int contor = 1;//contor care reprezinta zona concentrica
	int i1, i2, i3, i4,saptamani,c;//indici pentru parcurgeri
	
	//initializare vectori
	for(k = 0; k < NC; k++){
		vector_culori[k] = 1000;
		numar_culori[k] = 0;
		vector1[k] = -500;
	}
	
	//citire urmatoarelor linii din fisier care reprezinta elementele matricii de ‌intrare
	for(i = 0; i < dim_matrice; i++)
		for(j = 0; j < dim_matrice; j++){
			fscanf(fisin,"%i",&x);
            matrice[i][j] = x;		
		}
	fclose(fisin);//inchidere fisier
	
	//initializare elemente matrice de intrare
	for(i = 0; i < dim_matrice; i++){
		for(j = 0; j < dim_matrice; j++){
			matrice_iesire[i][j] = -1;
		}
	}
	
	//parcurgere numar saptamani
	for(saptamani = 0; saptamani < nr_saptamani; saptamani++){
		//initializare vectorul cu numar partide
		for(m = 0; m < NC; m++)
			numar_culori[m] = 0;
		//parcurgere matrice
		for(i = 0; i < dim_matrice; i++){
			for(j = 0; j < dim_matrice; j++){
				contor = 1;
				//initializare vector cu distante minime
				for(k = 0; k < NC; k++)
					vector_culori[k] = 1000;
				if(copy[matrice[i][j]] == 1)
					vector_culori[matrice[i][j]] = 0;
					
				//atata timp cat vectorul cu distante minime nu e completat
				while(maxim_vector(vector_culori, NC, vector1) == 1000){
					//i aceste if-uri tratez marginile matricii
					if(i - contor <= 0) afara = 0; else afara = i - contor;
					if(i + contor > dim_matrice - 1) afara1 = dim_matrice - 1; else afara1 = i + contor;
					if(j - contor <= 0) afara2 = 0; else afara2 = j - contor;
					if(j + contor > dim_matrice - 1) afara3 = dim_matrice - 1; else afara3 = j + contor;
					
					//parcurg zonle concentrice
					for(i1 = afara; i1 <= afara1; i1++){
						if(afara2 == j && i1 == i)
							vector_culori[matrice[i1][afara2]] = vector_culori[matrice[i1][afara2]];
						else
							vector_culori[matrice[i1][afara2]] = minim(vector_culori[matrice[i1][afara2]], contor);
					}
					
					for(i2 = afara; i2 <= afara1; i2++){
						if(afara3 == j && i2 == i)
							vector_culori[matrice[i2][afara3]] = vector_culori[matrice[i2][afara3]];
						else
							vector_culori[matrice[i2][afara3]] = minim(vector_culori[matrice[i2][afara3]], contor);
					}
				
					for(i3 = afara2+1; i3 <= afara3-1; i3++){
						if(afara == i && i3 == j)
							vector_culori[matrice[afara][i3]] = vector_culori[matrice[afara][i3]];
						else
							vector_culori[matrice[afara][i3]] = minim(vector_culori[matrice[afara][i3]], contor);
					}
					
					for(i4 = afara2+1; i4 <= afara3-1; i4++){
						if(afara1 == i && i4 == j)
							vector_culori[matrice[afara1][i4]] = vector_culori[matrice[afara1][i4]];
						else
							vector_culori[matrice[afara1][i4]] = minim(vector_culori[matrice[afara1][i4]], contor);
						
					}
					contor++;
				}
				matrice_iesire[i][j] = maxim(vector_culori, NC);
				numar_culori[maxim(vector_culori, NC)] ++;//cresc numarul de partide
				}
			}//sfarsit elemente matrice
			
		//reinitializare matrice de intrare
		for(i1 = 0; i1 < dim_matrice; i1++)
			for(i2 = 0; i2 < dim_matrice; i2++)
				matrice[i1][i2] = matrice_iesire[i1][i2];
			
		for(n = 0; n < NC; n++){
			//printf("%i   ", numar_culori[n]);
			fprintf(fisout,"%i ", numar_culori[n]);
			copy[n] = numar_culori[n];
			if(numar_culori[n] == 0)
				vector1[n] = n;
		}
		fprintf(fisout,"\n");
	
	}//sfarsit saptamani
	
	for(i = 0; i < dim_matrice; i++){
		for(j = 0; j < dim_matrice; j++){
			fprintf(fisout,"%i ", matrice_iesire[i][j]);
		}
		fprintf(fisout,"\n");
	}
	
	return 0;
}
