#include<stdio.h>
#include<stdlib.h>

//functie care returneaza modulul unui numar pentru calculul distantei
int module(int n){
	if(n < 0)
		return -n;
	else
		return n;
}
//functie care returneaza maximul dintr-un vector
int maxim(int v[], int num_elements){
	int max = -1;
	int i;
	for(i = 0; i < num_elements; i++){
		if(v[i] > max)
			max = v[i];
	}
	return max;
}

//functie care returneaza maximul dintre doua numere pozitive
int maxim_1(int n1, int n2){
	int max = 0;
	if(n1 >= n2)
		max = n1;
	else
		max = n2;
		
	return max;
}

int main(int argc,char *argv[]){
	int dim_matrice;//dimensiune matrice intrare
	int NC;//numarul de [artide
    int nr_saptamani;//numar saptamani
	
	FILE *fisin, *fisout;//fisierele de intrare respectiv iesire
	fisin = fopen(argv[2], "r");//deschid fisierul de intrare pentru citire(al doilea argument)
	fisout = fopen(argv[3], "w");//deschid fiaierul de iesire pentru scriere(al treilea argument)
	nr_saptamani = atoi(argv[1]);//primul argument
	int x;
	int i,j,k,m,n,maxim_vector=0;//indici pentru parcurgeri
	fscanf(fisin,"%i",&dim_matrice);//citesc prima linie din fisier care este dimensiunea matrici
	int matrice[dim_matrice][dim_matrice];//matricea de intrare
	int matrice_iesire[dim_matrice][dim_matrice];//matricea de iesire
	fscanf(fisin,"%i",&NC);//citesc a doua linie din fisier care reprezinta numarul de partide
	int vector_culori[NC];//vector in care retin distantele minime
	int numar_culori[NC];//vector in care retin numarul partidelor dupa fiecare saptamana
	//initializare elemente vectori
	for(k = 0; k < NC; k++){
		vector_culori[k] = -1;
		numar_culori[k] = 0;
	}
	//citire urmatoarelor linii din fisier care reprezinta elementele matricii de ‌intrare
	for(i = 0; i < dim_matrice; i++)
		for(j = 0; j < dim_matrice; j++){
			fscanf(fisin,"%i",&x);
            matrice[i][j] = x;		
		}
	fclose(fisin);	//inchidere fisier
	//initializare elemente matrice
	for(i = 0; i < dim_matrice; i++){
		for(j = 0; j < dim_matrice; j++){
			matrice_iesire[i][j] = -1;
		}
	}
	
	int i1 = 0, i2 = 0, w = 0, element = 0, max_numere = 0;

for(w = 0; w < nr_saptamani; w++){//parcurg numarul de saptamani
	for(i = 0; i < dim_matrice; i++){//parcurg matricea de intrare
		for(j = 0; j < dim_matrice; j++){
			//parcurgere matrice de intrare si calculul urmatorii culori pentru fiecare element din matrice 
			for(m = 0; m < dim_matrice; m++){
				for(n = 0; n < dim_matrice; n++){
						max_numere = maxim_1(module(m - i), module(n - j));//distanta minima
						if(((vector_culori[matrice[m][n]] == -1) && (max_numere != 0)) || ((max_numere < vector_culori[matrice[m][n]]) && (max_numere != 0))){
							vector_culori[matrice[m][n]] = max_numere;
						}
					}
		
			}
			maxim_vector = maxim(vector_culori, NC);//culoarea va fi maximul din vectoru_culori
			for(k = 0; k < NC; k++)
				//calcul numar partide
				if(maxim_vector == vector_culori[k]){
					matrice_iesire[i][j] = k;
					numar_culori[k]++;
					break;
					}
			//reinitializare vector
			for(k = 0; k < NC; k++)
				vector_culori[k] = -1;
		}
	}
	//reinitializare matrice de intrare dupa fiecare saptamana
	for(i1 = 0; i1 < dim_matrice; i1++)
		for(i2 = 0; i2 < dim_matrice; i2++)
			matrice[i1][i2] = matrice_iesire[i1][i2];
	
	//scriere in fisierul de iesire numr partide dupa fiecare saptamana
	for(i1 = 0; i1 < NC; i1++)
		fprintf(fisout,"%i ", numar_culori[i1]);
	fprintf(fisout,"\n");
	
	//reinitializare vector care retine numarul de partide dintr-o saptamana
	for(i1 = 0; i1 < NC; i1++)
		numar_culori[i1] = 0;
}
    //scriere in fisierulde iesire matrice de iesire dupa cele nr_saptamani saptamani
	for(i = 0; i < dim_matrice; i++){
		for(j = 0; j < dim_matrice; j++){
			fprintf(fisout,"%i ", matrice_iesire[i][j]);
		}
		fprintf(fisout,"\n");
	}
	
	return 0;	
}
